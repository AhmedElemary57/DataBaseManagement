#!/bin/bash
gnome-terminal -- bash -c "java -jar /home/elemary/Projects/DataBaseManagement/out/artifacts/DataBaseManagement_jar/DataBaseManagement.jar 7 7 20 3 10 10 2 2; exec bash"
