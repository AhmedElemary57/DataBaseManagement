package org.example;

import java.io.IOException;

public class CompactionThread extends Thread{
    LSMTree lsmTree;
    public CompactionThread(LSMTree lsmTree) {
        this.lsmTree = lsmTree;
    }


    @Override
    public void run() {
        while (true){
            try {
                Thread.sleep(20000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            System.out.println("CompactionThread started and was done by Thread number "+Thread.currentThread().getId());
            try {
                lsmTree.mergeCompaction();

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("CompactionThread finished and was done by Thread number "+Thread.currentThread().getId());
            }
        }
}
