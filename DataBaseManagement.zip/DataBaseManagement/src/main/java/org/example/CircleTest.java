package org.example;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class CircleTest extends JPanel {

    private static final int SIZE = 10000;
    private int a = SIZE / 2;
    private int b = a;
    private int r = 4 * SIZE / 5;
    private int n;

    /** @param n  the desired number of circles. */
    public CircleTest(int n) {
        super(true);
        this.setPreferredSize(new Dimension(SIZE, SIZE));
        this.n = n;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.black);
        a = getWidth() / 2;
        b = getHeight() / 2;
        int m = Math.min(a, b);
        r = 4 * m / 5;
        int r2 = Math.abs(m - r) / 8;
        g2d.drawOval(a - r, b - r, 2 * r, 2 * r);
        int[] array={-25,0};
        RingStructure ringStructure=RingStructure.getInstance(5,5,3);
        ringStructure.buildMap(5);
        Map<Integer,Color> map=new HashMap<>();
        for (int i = 1; i <= 5; i++) {
            map.put(5000+i,new Color((int)(Math.random() * 0x1000000)));

        }
        for (int i = 0; i < ringStructure.keys.size(); i++) {
            long val= (long) (ringStructure.keys.get(i)+Math.pow(2,31));
            long max= (long) Math.pow(2, 32);
            double t = 2 * Math.PI * val/max ;
            int x = (int) Math.round(a + r * Math.cos(t));
            int y = (int) Math.round(b + r * Math.sin(t));
            Color color=map.get(ringStructure.nodes_Ports.get(ringStructure.keys.get(i)));
            g2d.setColor(color);
            g2d.drawString(String.valueOf(ringStructure.keys.get(i)),x,y);
            g2d.fillOval(x - r2, y - r2, 2 * r2, 2 * r2);

        }
    }

    private static void create() {
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(new CircleTest(100));
        f.pack();
        f.setVisible(true);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                create();
            }
        });
    }
}